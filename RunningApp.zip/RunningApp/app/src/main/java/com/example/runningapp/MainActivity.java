package com.example.runningapp;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.runningapp.MyContentProvider.CONTENT_URL;

public class MainActivity extends AppCompatActivity {

    CursorAdapter cursoradapter;
    ContentResolver resolver;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mapButton();
        getList();
        refreshButton();
    }

    public void refreshButton()
    {
        Button refresh = (Button)findViewById(R.id.refreshButton);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getList();
            }
        });
    }

    public void mapButton()
    {
        Button mapbutton = (Button)findViewById(R.id.mapButton);
        mapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,MapsActivity.class);
                startActivity(intent);
            }
        });
    }

    public void getList() // Retrieves the inserted data from using the content resolver and is read by a cursor which is adapted to be able to be inserted into a listview
    {
        Uri uri = CONTENT_URL;

        String[] projection = {MyContentProvider.id, MyContentProvider.name, MyContentProvider.distance};
        String[] From = {MyContentProvider.id, MyContentProvider.name, MyContentProvider.distance};
        int[] to = {R.id.listid, R.id.listName, R.id.listDistance};

        Cursor customCursor = getContentResolver().query(uri,projection, null, null, null);
        cursoradapter = new SimpleCursorAdapter(this, R.layout.title_list, customCursor, From, to, 0);
        ListView listView = (ListView) findViewById( R.id.listView );
        listView.setAdapter(cursoradapter);
    }

    /*public void deleteRecipe(View view)// Retrieves the desired id for deletion and checks if the text box for deletion is empty, the matching id of the
    // database with the textbox will be deleted and then a new list is shown in the listview
    {
        Uri uri = CONTENT_URL;
        TextView textView = (TextView)findViewById(R.id.deleteText);
        String DeleteId = textView.getText().toString();

        if(!TextUtils.isEmpty(DeleteId))
        {
            long idDelete = resolver.delete(CONTENT_URL,"_id = ?",new String[]{DeleteId});
            getList();
        }
        else
        {
            Toast.makeText(getBaseContext(), "Enter an ID to delete...", Toast.LENGTH_LONG ).show();
        }

    }*/
}
